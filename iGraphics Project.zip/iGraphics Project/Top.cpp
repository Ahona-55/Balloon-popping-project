#include "iGraphics.h"
#include<stdio.h>
#include<string.h>
#include "windows.h"
void score();
void reset();
void move();
void changeY();
char redLoon[50] = "image\\redBalloon.bmp";
char greenLoon[50] = "image\\greenBalloon.bmp";
char blow[50] = "image\\blow.bmp";
char aim[50] = "image\\aimLogo.bmp";
char str[50];

int xBalloon = 100;
int yBalloon = 400;
int dBalloon = 80;

int xTarget = 200, yTarget = 200;
bool blastBalloon = false;
bool showBallloon = true;

int loonCount = 0;
int flag = 0;

//:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::Idraw Here::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::://

void iDraw()
{
	iClear();
	char *p1, *p2;
	if (yBalloon < 0){
		flag = 1;
	}

	if (loonCount % 2 == 0){
		p1 = str;
		while (*p1 != '\0')
		{
			*p1 = '\0';
			*p1++;
		}
		p1 = redLoon;
		p2 = str;

		while (*p1 != '\0'){
			*p2 = *p1;
			p1++;
			p2++;
		}
		//strcpy(greenLoon, redLoon);
	}

	else if (loonCount % 2 != 0){
		
		p1 = str;
		while (*p1 != '\0')
		{
			*p1 = '\0';
			*p1++;
		}
		p1 = greenLoon;
		p2 = str;
		while (*p1 != '\0'){
			*p2 = *p1;
			p1++;
			p2++;
		}

		//strcpy(ballon, green);
	}

	if (showBallloon){
		iShowBMP2(xBalloon, yBalloon, str, 0);

	}
	while (blastBalloon){
	
		iShowBMP2(xBalloon, yBalloon, blow, 0);
		
	}

	iShowBMP2(xTarget, yTarget, aim, 0);
	if (flag == 1){
		iText(150, 300, "YOU LOOSE", GLUT_BITMAP_TIMES_ROMAN_24);

	}





}





/*function iMouseMove() is called when the user presses and drags the mouse.
(mx, my) is the position where the mouse pointer is.
*/


void iMouseMove(int mx, int my)
{
	
}
//*******************************************************************ipassiveMouse***********************************************************************//
void iPassiveMouseMove(int mx, int my)
{
	xTarget = mx - 40;
	yTarget = my - 40;
}

void iMouse(int button, int state, int mx, int my)
{
	
	if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
	{
		if (mx >= xBalloon && mx <= xBalloon + dBalloon && my >= yBalloon && my <= yBalloon + dBalloon){

			
			++loonCount;
			showBallloon = false;
			blastBalloon = true;
			//Sleep(500);
			blastBalloon = false;
			iShowBMP2(xBalloon, yBalloon, blow, 0);

			score();
			reset();
			move();
			

		}
		
	}
	
	
	if (button == GLUT_RIGHT_BUTTON && state == GLUT_DOWN)
	{
		
	}
}

/*
function iKeyboard() is called whenever the user hits a key in keyboard.
key- holds the ASCII value of the key pressed.
*/


void iKeyboard(unsigned char key)
{
	if (key == '\r')
	{
		
	}
	
	
}

/*
function iSpecialKeyboard() is called whenver user hits special keys like-
function keys, home, end, pg up, pg down, arraows etc. you have to use
appropriate constants to detect them. A list is:
GLUT_KEY_F1, GLUT_KEY_F2, GLUT_KEY_F3, GLUT_KEY_F4, GLUT_KEY_F5, GLUT_KEY_F6,
GLUT_KEY_F7, GLUT_KEY_F8, GLUT_KEY_F9, GLUT_KEY_F10, GLUT_KEY_F11, GLUT_KEY_F12,
GLUT_KEY_LEFT, GLUT_KEY_UP, GLUT_KEY_RIGHT, GLUT_KEY_DOWN, GLUT_KEY_PAGE UP,
GLUT_KEY_PAGE DOWN, GLUT_KEY_HOME, GLUT_KEY_END, GLUT_KEY_INSERT
*/
void iSpecialKeyboard(unsigned char key)
{

	
	if (key == GLUT_KEY_RIGHT)
	{
				
	}
	if (key == GLUT_KEY_LEFT)
	{
		
	}
	
	if (key == GLUT_KEY_HOME)
	{
		
	}
	
}


void changeY(){
	yBalloon -= 5;
}

void score(){
	printf("%d\n", loonCount);
}
void move(){
	if (loonCount % 2 == 0)
		xBalloon +=  100;
	else if (loonCount % 2 != 0)
		xBalloon -=  100;

}

void reset(){
	xBalloon = 100;
	yBalloon = 400;
	blastBalloon = false;
	showBallloon = true;
	flag = 0;
}

int main()
{
	iSetTimer(100, changeY);
	iInitialize(400, 400, "Project Title");
	iStart();
	return 0;
}