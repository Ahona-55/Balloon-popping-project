# include "iGraphics.h"

int redspd=7,greenspd=5,over=0;
int red,green,blust;
int redx=150 , greenx=50;
int redy=400,greeny=400;
int vice=1,blast=0;
int mousex=0 , mousey=0;
int blax,blay,go=1,score;
char sco;

void iDraw()
{
	iClear();
	
	if(go%2!=0)
	{
		iShowBMP(redx,redy,"redBalloon.bmp");
	}
	if(go%2==0)
	{
		iShowBMP(greenx,greeny,"greenBalloon.bmp");
	}
	iShowBMP2((mousex-20), (mousey-20) , "aimLogos.bmp",0);
    
	iSetColor(0,255,0);
	iText(240, 370, "Player Name ->" "score");
	//printf("score : %d\n",score);

	iSetColor(255, 192, 203);
	
	iText(250, 350, "ABIR ----->" );

	if(redy <= 0 || greeny <= 0)
	{
		iSetColor(255,0 , 0);
		iText(150,200,"GAME OVER !!!!!");
	}
	if(blast==1)
	{
		iShowBMP(blax,blay,"blow.bmp");
		go++;
		blast=0;
	}
}

void iMouseMove(int mx, int my)
{
	//place your codes here
}

void iPassiveMouse(int mx, int my)
{
	mousex = mx;
	mousey =my;
	//printf("%d, %d\n",mousex,mousey);
}


void iMouse(int button, int state, int mx, int my)
{
	if(button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
	{
		int i,j;
		for(i=redx ; i<=(redx+80); i++)
		{
			for(j=redy ; j<=(redy+80) ; j++)
			{
				if((mx==i) && (my==j))
				{
					blast=1;
					blax=redx;
					blay=redy;
					redx=150 , greenx=50;
					score=score+20;
				}
			}
		}
		for(i=greenx ; i<=(greenx+80); i++)
		{
			for(j=greeny ; j<=(greeny+80) ; j++)
			{
				if((mx==i) && (my==j))
				{
					blast=1;
					blax=greenx;
					blay=greeny;
					redy=400,greeny=400;
					score=score+10;
				}
			}
		}
	}
	if(button == GLUT_RIGHT_BUTTON && state == GLUT_DOWN)
	{
		//place your codes here
	}
}

void iKeyboard(unsigned char key)
{
	if(key == 'p')
	{
		iPauseTimer(0);
	}
	if(key == 'r')
	{
		iResumeTimer(0);
	}
}

void iSpecialKeyboard(unsigned char key)
{
	if(key == GLUT_KEY_END)
	{
		exit(0);	
	}
}

void balloon(){

	if(go%2!=0)
	{
		redy -=redspd;
	}
	if(go%2==0)
	{
		greeny -=greenspd;
	}
	printf("score : %d\n",score);
}
int main()
{
	//place your own initialization codes here. 
	iSetTimer(50, balloon);
	iInitialize(400,400, "Balloon Game");
	iStart();
	
	return 0;
}

